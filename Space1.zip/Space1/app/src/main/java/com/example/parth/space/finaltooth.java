package com.example.parth.space;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class finaltooth extends AppCompatActivity {

     String username="";

    Button onBtn, offBtn, pairBtn, fndBtn, onDevBtn, offDevBtn;

    ListView lv;

    private ArrayAdapter<String> mArrayAdapter;

    private static String address = "9C:02:98:B1:90:B3";

    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothSocket btSocket = null;
    private OutputStream outStream = null;

    ArrayList<BluetoothDevice> arrayListBluetoothDevices = null;

    BluetoothAdapter mBtAdapter;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */


    public void on(View view) {
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        if (mBtAdapter == null) {
            Toast.makeText(getApplicationContext(), "Device not supported", Toast.LENGTH_LONG).show();
        } else if (mBtAdapter.isEnabled()) {
            Toast.makeText(getApplicationContext(), "Bluetooth is On", Toast.LENGTH_LONG).show();

            Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivityForResult(i, 1);
        } else {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);

            if (mBtAdapter.isEnabled()) {
                Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                startActivity(i);
            }
        }
    }

    public void off(View view) {
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        if (mBtAdapter == null) {
            ShowMessage("Null Adapter");
        } else if (mBtAdapter.isEnabled()) {
            mBtAdapter.disable();
            ShowMessage("Bluetooth OFF");
        }
    }

    public void pairShow(View view) {

        ShowMessage("Paired Clicked");

        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        Set<BluetoothDevice> pairedDevice = mBtAdapter.getBondedDevices();

        // Set<BluetoothDevice> pairedDevice = mBtAdapter.getRemoteDevice(address);

        lv = (ListView) findViewById(R.id.listView2);


        final ArrayList pairedDevicesArrayList = new ArrayList();
        final ArrayList pairedAddress = new ArrayList();
        if (pairedDevice.size() > 0) {
            //for(BluetoothDevice bluetoothDevice : pairedDevice)
            for (BluetoothDevice bluetoothDevice : pairedDevice) {


                pairedDevicesArrayList.add(bluetoothDevice.getName());
                pairedAddress.add(bluetoothDevice.getAddress());
                //arrayListBluetoothDevices.add(bluetoothDevice);
                // in newer version
                // 9C:02:98:B1:90:B3
                //pairedDevicesArrayList.add(bluetoothDevice.getName());
            }

            ArrayAdapter arrayAdapter = new ArrayAdapter(finaltooth.this, android.R.layout.simple_list_item_1, pairedDevicesArrayList);

            lv.setAdapter(arrayAdapter);


            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    ///ShowMessage("ListItem clickedx");

                    //BluetoothDevice bdDevice = arrayListBluetoothDevices.get(position);

                    String bdev = pairedAddress.get(position).toString();

                    //ShowMessage(bdev);

                    address = bdev;

                    BluetoothDevice device = mBtAdapter.getRemoteDevice(address);
                    try {
                        ShowMessage("Connecting....");

                        btSocket = creatBluetoothSocket(device);

                        //ShowMessage("now send message");

                    } catch (IOException ex) {
                        ShowMessage("Fatal Error");
                    }


                    mBtAdapter.cancelDiscovery();

                    try {
                        btSocket.connect();
                    } catch (Exception ex) {
                        try {
                            btSocket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    try {
                        outStream = btSocket.getOutputStream();

                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            });
        }
    }

    public void sendOne(View view)
    {
        try {
            outStream = btSocket.getOutputStream();

            sendData("2");

            //ShowMessage("Data Two Sent");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }

    }

    public void sendTwo(View view)
    {
        try {
            outStream = btSocket.getOutputStream();

            sendData("1");

            //ShowMessage("Data One Sent");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }

    }


    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            ShowMessage("Hello");
            String action = intent.getAction();
            String n = "Hello";
            ArrayList list1 = new ArrayList();


            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Get the BluetoothDevice object from the Intent
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // Add the name and address to an array adapter to show in a ListView
                n = n + device.getName();
                list1.add(device.getName());

            }
            ArrayAdapter arrayAdapter = new ArrayAdapter(finaltooth.this, android.R.layout.simple_list_item_1, list1);
            ShowMessage(n);
            lv.setAdapter(arrayAdapter);
        }
    };

    private BluetoothSocket creatBluetoothSocket(BluetoothDevice device) throws IOException {
        if (Build.VERSION.SDK_INT >= 10) {
            try {
                final Method m = device.getClass().getMethod("createInsecureRfcommSocketToServiceRecord", new Class[]{UUID.class});
                ShowMessage("Connected....");
                return (BluetoothSocket) m.invoke(device, MY_UUID);
            } catch (Exception ex) {
                ex.printStackTrace();
                ShowMessage("Could not connect Socket");
            }

        }
        return device.createRfcommSocketToServiceRecord(MY_UUID);
    }

    /*@Override
    public void onResume()
    {
        super.onResume();

        BluetoothDevice device = mBtAdapter.getRemoteDevice(address);
        try
        {
            btSocket = creatBluetoothSocket(device);

        }
        catch(IOException ex)
        {
            ShowMessage("Fatal Error");
        }


        mBtAdapter.cancelDiscovery();

        try
        {
            btSocket.connect();
        }
        catch(Exception ex)
        {
            try {
                btSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try
        {
            outStream = btSocket.getOutputStream();
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }
    }*/

    /*@Override
    public void onPause() {
        super.onPause();


        if (outStream != null) {
            try {
                outStream.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try     {
            btSocket.close();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }*/



    private void sendData(String message) {
        byte[] buffer = message.getBytes();

        try {
            outStream.write(buffer);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finaltooth);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        username = getIntent().getStringExtra("username");


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    public void ShowMessage(String str) {
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_LONG).show();
    }


    public void startConf() {
        onBtn = (Button) findViewById(R.id.onBtn);

        offBtn = (Button) findViewById(R.id.offBtn);

        pairBtn = (Button) findViewById(R.id.pairBtn);


        onDevBtn = (Button) findViewById(R.id.onDevBtn);

        offDevBtn = (Button) findViewById(R.id.offDevBtn);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_setting) {
            return true;
        }
        else if(id==R.id.home){
            Intent i1 = new Intent(finaltooth.this,Home.class);
            startActivity(i1);
        }
        else if(id==R.id.pro){
            Intent i1 = new Intent(finaltooth.this,Profile.class);
            startActivity(i1);
        }
        else if(id==R.id.chng){
            Intent i1 = new Intent(finaltooth.this,ChangePassword.class);
            startActivity(i1);
        }
        else if(id==R.id.fee){
            Intent i1 = new Intent(finaltooth.this,Feed_back.class);
            startActivity(i1);
        }

        else if(id==R.id.aboutus){
            Intent i1 = new Intent(finaltooth.this,AboutUs.class);
            startActivity(i1);
        }


        else if(id==R.id.log){
            Intent i1 = new Intent(finaltooth.this,Home.class);
            startActivity(i1);
        }






        return super.onOptionsItemSelected(item);
    }
}
