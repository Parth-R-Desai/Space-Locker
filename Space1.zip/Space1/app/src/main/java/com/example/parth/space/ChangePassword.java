package com.example.parth.space;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.parth.space.Database;
import com.example.parth.space.R;

public class ChangePassword extends AppCompatActivity {

    TextView t1;

    SharedPreferences sp;

     Database myDB;
    Button b1;
    EditText e1,e2,e3;

    String MyPreference = "MyPref";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        b1 = (Button)findViewById(R.id.chngbtn);

        e1 = (EditText)findViewById(R.id.oldpwd);
        e2 = (EditText)findViewById(R.id.newpwd);
        e3 = (EditText)findViewById(R.id.cnfpwd);

        myDB = new Database(this);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = "vaibhavipatel169@gmail.com";

                String opwd = e1.getText().toString();

                String npwd = e2.getText().toString();


                Cursor c1 = myDB.getPwd(email);

                int i = c1.getCount();
                String p="";
                if(i>0)
                {
                    int passIndex = c1.getColumnIndex("password");
                    while(c1.moveToNext()) {
                        p = c1.getString(passIndex);
                    }
                    if(p.equals(opwd)) {

                        if(myDB.ChangePwd(npwd,email))
                            Toast.makeText(getApplicationContext(),"Password Changed", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(getApplicationContext(), "Not Changed", Toast.LENGTH_LONG).show();
                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"UserName Invalid",Toast.LENGTH_LONG).show();
                }


            }
        });



        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

}
