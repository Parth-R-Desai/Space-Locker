package com.example.parth.space;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LgnActivity extends AppCompatActivity {

    EditText e1,e2;
    Button b1;

    String username="";
Database myDB;


    public void go(View v) {
        Intent i1 = new Intent(LgnActivity.this, Reg.class);

        startActivity(i1);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lgn);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        username = getIntent().getStringExtra("username");


        e1 = (EditText) findViewById(R.id.emailtxt);
        e2 = (EditText) findViewById(R.id.passtxt);
        b1 = (Button) findViewById(R.id.button);

myDB = new Database(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String f1 = e1.getText().toString();

                String f2 = e2.getText().toString();

                Cursor C = myDB.getData(f1, f2);

                int i = C.getCount();


                if (!isValidEmail(f1)) {
                    e1.setError("Invalid Email");
                }

                if (!isValidPassword(f2)) {
                    e2.setError("Invalid Password");
                }

                if ((isValidEmail(f1)) && (isValidPassword(f2))) {

                    if (i > 0) {

                        Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_LONG).show();
                        Intent i1 = new Intent(LgnActivity.this,OTP.class);
                        i1.putExtra("username",f1);
                        startActivity(i1);

                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),"Invalid User",Toast.LENGTH_LONG).show();

                    }

                }


            }
        });




        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }
    private boolean isValidEmail(String e) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(e);
        return matcher.matches();
    }

    // validating password with retype password
    private boolean isValidPassword(String p) {
        if (p != null && p.length() > 6) {
            return true;
        }
        return false;
    }



    public void fot(View v) {
        Intent i1 = new Intent(LgnActivity.this, FgtActivity.class);

        startActivity(i1);
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_setting) {
            return true;
        }
        else if(id==R.id.home){
            Intent i1 = new Intent(LgnActivity.this,Home.class);
            startActivity(i1);
        }
        else if(id==R.id.pro){
            Intent i1 = new Intent(LgnActivity.this,Profile.class);
            startActivity(i1);
        }
        else if(id==R.id.chng){
            Intent i1 = new Intent(LgnActivity.this,ChangePassword.class);
            startActivity(i1);
        }
        else if(id==R.id.fee){
            Intent i1 = new Intent(LgnActivity.this,Feed_back.class);
            startActivity(i1);
        }

        else if(id==R.id.aboutus){
            Intent i1 = new Intent(LgnActivity.this,AboutUs.class);
            startActivity(i1);
        }


        else if(id==R.id.log){
            Intent i1 = new Intent(LgnActivity.this,Home.class);
            startActivity(i1);
        }






        return super.onOptionsItemSelected(item);
    }
}
