package com.example.parth.space;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Profile extends AppCompatActivity {
    EditText e1,e2;
    EditText e3,e4;
    Button b1;

    Database myDB;

    String username="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_h);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        username = getIntent().getStringExtra("username");

        Toast.makeText(getApplicationContext(),username,Toast.LENGTH_LONG).show();

        myDB = new Database(this);

        e1 = (EditText) findViewById(R.id.emtxt);

        e3 = (EditText) findViewById(R.id.nam);
        e4 = (EditText) findViewById(R.id.phon);




        Cursor c1 = myDB.getProfile(username);
        int i = c1.getCount();
        String p="";
        if(i>0)
        {
            int passname = c1.getColumnIndex("name");
            int passemail = c1.getColumnIndex("email");
            int contact = c1.getColumnIndex("contact");
            while(c1.moveToNext()) {
                //c1.getString(passIndex);

                e1.setText(c1.getString(passemail));
                e3.setText(c1.getString(passname));
                e4.setText(c1.getString(contact));

            }
            Toast.makeText(getApplicationContext(), p, Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Record Not Found",Toast.LENGTH_LONG).show();
        }




        b1 = (Button)findViewById(R.id.btnupdate);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = e3.getText().toString();
                String contact = e4.getText().toString();

                if(myDB.ChangeProfile(name,contact,username))
                    Toast.makeText(getApplicationContext(),"Profile Updated", Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(getApplicationContext(), "Profile Not Updated", Toast.LENGTH_LONG).show();
            }
        });



        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.profile, menu);


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_setting) {
            return true;
        }
        else if(id==R.id.home){
            Intent i1 = new Intent(Profile.this,Home.class);
            startActivity(i1);
        }
        else if(id==R.id.pro){
            Intent i1 = new Intent(Profile.this,Profile.class);
            startActivity(i1);
        }
        else if(id==R.id.chng){
            Intent i1 = new Intent(Profile.this,ChangePassword.class);
            startActivity(i1);
        }
        else if(id==R.id.fee){
            Intent i1 = new Intent(Profile.this,Feed_back.class);
            startActivity(i1);
        }

        else if(id==R.id.aboutus){
            Intent i1 = new Intent(Profile.this,AboutUs.class);
            startActivity(i1);
        }


        else if(id==R.id.log){
            Intent i1 = new Intent(Profile.this,Home.class);
            startActivity(i1);
        }






        return super.onOptionsItemSelected(item);
    }
}
