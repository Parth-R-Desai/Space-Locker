package com.example.parth.space;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;
import android.telephony.SmsManager;

public class OTP extends AppCompatActivity {

    Database myDB;

    String username="";

    Button b1,b2,b3;

    EditText e1;


    public static int otp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        myDB = new Database(this);


        b1 = (Button)findViewById(R.id.btnok);

        b2 = (Button)findViewById(R.id.getOtp);

        b3 = (Button)findViewById(R.id.cntbtn);

        e1 = (EditText)findViewById(R.id.edtxt2);



        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(OTP.this,finaltooth.class);
                i2.putExtra(username,"username");
                startActivity(i2);
            }
        });


        username = getIntent().getStringExtra("username");



        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String pno ="";

                Cursor c1 = myDB.getPwd(username);

                int i = c1.getCount();


                if (i > 0) {
                    int passIndex = c1.getColumnIndex("contact");
                    while (c1.moveToNext()) {

                        pno = c1.getString(passIndex);


                    }

                    //Toast.makeText(getApplicationContext(),pno,Toast.LENGTH_LONG).show();

                    otp = getRandom();

                    String msg = "Your OTP is : " + otp;

                    try {


                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(pno, null, msg, null, null);

                        Toast.makeText(getApplicationContext(), "Send SMS", Toast.LENGTH_LONG).show();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_LONG).show();
                    }
                }

            }
        });


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int val = Integer.parseInt(e1.getText().toString());

                if(val == otp) {

                    Intent t1 = new Intent(OTP.this,finaltooth.class);
                    t1.putExtra("username",username);
                    startActivity(t1);
                }
                else {
                    Toast.makeText(getApplicationContext(),"OTP is wrong",Toast.LENGTH_LONG).show();
                }

            }
        });







            FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }


    private int getRandom()
    {
        Random r = new Random();

        int v = r.nextInt(9999);

        return v;
    }
}
