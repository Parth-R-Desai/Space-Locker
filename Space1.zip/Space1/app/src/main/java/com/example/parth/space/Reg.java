package com.example.parth.space;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Reg extends AppCompatActivity {

    String username="";

    EditText e,e2,e3,e4,e6;
    Button b1;

    Database myDB;







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        username = getIntent().getStringExtra(username);


        myDB = new Database(this);

        e = (EditText) findViewById(R.id.nm);
         e4 = (EditText) findViewById(R.id.pass1);
         e2 = (EditText) findViewById(R.id.em);
        e6 = (EditText) findViewById(R.id.con);
        b1 = (Button) findViewById(R.id.btn3);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = e.getText().toString();

                String email = e2.getText().toString();

                String pass = e4.getText().toString();

                String con = e6.getText().toString();


                if (!isValidEmail(email)) {
                    e2.setError("Invalid Email");
                }

                if (!isValidPassword(pass)) {
                    e4.setError("Invalid Password");
                }

                if ((isValidEmail(email)) && (isValidPassword(pass))) {


                    try {
                        if (myDB.InsertData2(name, email, pass, con)) {
                            Toast.makeText(getApplicationContext(), "Registration Successfully", Toast.LENGTH_SHORT).show();
                            Intent i1 = new Intent(Reg.this,LgnActivity.class);
                            i1.putExtra("username",username);
                            startActivity(i1);
                        }
                    } catch (Exception ex) {
                        Toast.makeText(getApplicationContext(), "Not Done", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    private boolean isValidEmail(String e) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(e);
        return matcher.matches();
    }

    // validating password with retype password
    private boolean isValidPassword(String p) {
        if (p != null && p.length() > 6) {
            return true;
        }
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.profile, menu);


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_setting) {
            return true;
        }
        else if(id==R.id.home){
            Intent i1 = new Intent(Reg.this,Home.class);
            startActivity(i1);
        }
        else if(id==R.id.pro){
            Intent i1 = new Intent(Reg.this,Profile.class);
            startActivity(i1);

        }
        else if(id==R.id.chng){
            Intent i1 = new Intent(Reg.this,ChangePassword.class);
            startActivity(i1);
        }
        else if(id==R.id.fee){
            Intent i1 = new Intent(Reg.this,Feed_back.class);
            startActivity(i1);
        }

        else if(id==R.id.aboutus){
            Intent i1 = new Intent(Reg.this,AboutUs.class);
            startActivity(i1);
        }


        else if(id==R.id.log){
            Intent i1 = new Intent(Reg.this,Home.class);
            startActivity(i1);
        }






        return super.onOptionsItemSelected(item);
    }
}
