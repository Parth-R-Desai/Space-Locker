package com.example.parth.space;

/**
 * Created by Parth on 18-03-2016.
 */

    import android.content.ContentValues;
    import android.content.Context;
    import android.database.Cursor;
    import android.database.sqlite.SQLiteDatabase;
    import android.database.sqlite.SQLiteOpenHelper;

    public class Database extends SQLiteOpenHelper {


        public Database(Context context)
        {
            super(context,"Elocker.db",null,1);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {

            db.execSQL("CREATE TABLE CUSTOMER (ID INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL, password TEXT NOT NULL, contact INTEGER) ");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            db.execSQL("DROP TABLE IF EXISTS customer");
            onCreate(db);
        }



        public Cursor getData(String f,String n)
        {
            SQLiteDatabase db = this.getWritableDatabase();

            String q = "select * from CUSTOMER where email='"+f+"' and password='"+n+"' ";

            return db.rawQuery(q,null);
        }

        public Cursor getProfile(String f)
        {
            SQLiteDatabase db = this.getWritableDatabase();

            String q = "select * from CUSTOMER where email='"+f+"'";

            return db.rawQuery(q,null);
        }

        public Cursor getPwd(String f)
        {
            SQLiteDatabase db = this.getWritableDatabase();

            String q = "select * from CUSTOMER where email='"+f+"'";

            return db.rawQuery(q,null);


        }

        public boolean ChangeProfile(String name,String contact,String u)
        {
            SQLiteDatabase db = this.getWritableDatabase();

            String q = "Update CUSTOMER set name='"+name+"',contact='"+contact+"' where email='"+u+"'";

            try {
                db.execSQL(q);
                return true;
            }catch (Exception ex)
            {
                return false;
            }
        }



        public boolean InsertData2(String n,String e,String p,String c) {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues contentValues = new ContentValues();

            contentValues.put("name", n);
            contentValues.put("email", e);
            contentValues.put("password", p);
            contentValues.put("contact", c);


            long res = db.insert("CUSTOMER", null, contentValues);

            if (res == -1)
                return false;
            else
                return true;

        }
        public boolean ChangePwd(String p,String u)
        {
            SQLiteDatabase db = this.getWritableDatabase();

            String q = "Update CUSTOMER set password='"+p+"' where email='"+u+"'";

            try {
                db.execSQL(q);
                return true;
            }catch (Exception ex)
            {
                return false;
            }
        }


    }


