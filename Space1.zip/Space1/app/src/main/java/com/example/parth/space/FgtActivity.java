package com.example.parth.space;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.parth.space.AboutUs;
import com.example.parth.space.ChangePassword;
import com.example.parth.space.Database;
import com.example.parth.space.LgnActivity;
import com.example.parth.space.Profile;
import com.example.parth.space.R;

public class FgtActivity extends AppCompatActivity {
    EditText e1;
    Button b1;
    Intent i1,i2;

    Database myDB;

    public void lout(View v){
        Intent i1 = new Intent(FgtActivity.this, LgnActivity.class);
        startActivity(i1);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fgt);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        myDB = new Database(this);

        e1 = (EditText)findViewById(R.id.fgt1);
        b1 = (Button)findViewById(R.id.btnfgt);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = e1.getText().toString();

                Cursor c1 = myDB.getPwd(email);

                int i = c1.getCount();
                String p = "";
                if (i > 0) {
                    int passIndex = c1.getColumnIndex("password");
                    while (c1.moveToNext()) {
                        p = c1.getString(passIndex);

                    }
                    Toast.makeText(getApplicationContext(), p, Toast.LENGTH_LONG).show();
                    String sub,body;




                    sub = "Password";

                    body = p;

                    i1 = new Intent(Intent.ACTION_SEND);
                    i1.setData(Uri.parse("mailto:"));
                    String [] to= {
                            "vaibhavipatel169@gmail.com"
                    };
                    i1.putExtra(Intent.EXTRA_EMAIL,to);
                    i1.putExtra(Intent.EXTRA_SUBJECT,sub);
                    i1.putExtra(Intent.EXTRA_TEXT,body);
                    i1.setType("text/plain");
                    i2 = Intent.createChooser(i1,"SEND MAIL");
                    startActivity(i2);
                } else {
                    Toast.makeText(getApplicationContext(), "UserName Invalid", Toast.LENGTH_LONG).show();
                }
            }
        });
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_setting) {
            return true;
        }
        else if (id==R.id.home){
            Intent i1 = new Intent(FgtActivity.this,LgnActivity.class);
            startActivity(i1);
        }
        else if (id==R.id.pro){
            Toast.makeText(getApplicationContext(),"Login to use this feature",Toast.LENGTH_LONG).show();
            Intent i1 = new Intent(FgtActivity.this,Profile.class);
            startActivity(i1);
        }
        else if(id==R.id.chng){
            Toast.makeText(getApplicationContext(),"Login to use this feature",Toast.LENGTH_LONG).show();
            Intent i1 = new Intent(FgtActivity.this,ChangePassword.class);
            startActivity(i1);
        }
        else if(id==R.id.aboutus){
            Intent i1 = new Intent(FgtActivity.this,AboutUs.class);
            startActivity(i1);
        }


        return super.onOptionsItemSelected(item);
    }




}
