package com.example.parth.space;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login extends AppCompatActivity {

    EditText e1,e2;
    Button b1;
    Intent i1=null,i2=null;









    Database myDB;







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_login);







        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        myDB = new Database(this);
        e1 = (EditText) findViewById(R.id.l1);
        e2 = (EditText) findViewById(R.id.l2);
        b1 = (Button) findViewById(R.id.lb1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String f1 = e1.getText().toString();

                String f2 = e2.getText().toString();

                Cursor C = myDB.getData(f1, f2);

                int i = C.getCount();


                if (!isValidEmail(f1)) {
                    e1.setError("Invalid Email");
                }

                if (!isValidPassword(f2)) {
                    e2.setError("Invalid Password");
                }

                if ((isValidEmail(f1)) && (isValidPassword(f2))) {

                    if (i > 0) {
                        Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Invalid User", Toast.LENGTH_LONG).show();

                    }

                }


            }
        });




        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    private boolean isValidEmail(String e) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(e);
        return matcher.matches();
    }

    // validating password with retype password
    private boolean isValidPassword(String p) {
        if (p != null && p.length() > 6) {
            return true;
        }
        return false;
    }
}
